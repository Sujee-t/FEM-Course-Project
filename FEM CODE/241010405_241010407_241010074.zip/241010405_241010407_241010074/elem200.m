% Parameters
k = 50;              % Thermal conductivity (W/m.K)
Q = 1000;            % Heat source (W/m^2)
T_fixed = 25;        % Boundary temperature (°C)
Nx = 10;             % Elements along x
Ny = 10;             % Elements along y

% Generate structured grid
L = 1;
dx = L / Nx;
dy = L / Ny;
[x_grid, y_grid] = meshgrid(0:dx:L, 0:dy:L);
nodes = [x_grid(:), y_grid(:)];
n_nodes = size(nodes,1);

% Create triangular elements
elements = [];
for j = 1:Ny
    for i = 1:Nx
        n1 = i + (j-1)*(Nx+1);
        n2 = n1 + 1;
        n3 = n1 + (Nx+1);
        n4 = n3 + 1;

        % Triangle 1: lower-left to upper-right
        elements = [elements;
                    n1 n2 n4;
                    n1 n4 n3];
    end
end


%% Plot the mesh
figure;
trimesh(elements, nodes(:,1), nodes(:,2), 'LineWidth', 1);
title('Triangular Mesh for FEM Analysis');
xlabel('X Position (m)');
ylabel('Y Position (m)');
axis equal;
grid on;

%% Add annotations (optional)
hold on;
plot(nodes(:,1), nodes(:,2), 'ro', 'MarkerSize', 6); % Show nodes as red circles

% Print mesh statistics
fprintf('Mesh details:\n');
fprintf('Number of nodes: %d\n', n_nodes);
fprintf('Number of elements: %d\n', size(elements,1));

n_elements = size(elements,1);

% Initialize global matrices
K = zeros(n_nodes);
F = zeros(n_nodes,1);

% Assemble global stiffness matrix
for e = 1:n_elements
    idx = elements(e,:);
    coords = nodes(idx,:);
    x = coords(:,1); y = coords(:,2);
    
    A = polyarea(x, y);
    b = [y(2)-y(3); y(3)-y(1); y(1)-y(2)];
    c = [x(3)-x(2); x(1)-x(3); x(2)-x(1)];
    
    ke = (k / (4*A)) * (b*b' + c*c');
    K(idx, idx) = K(idx, idx) + ke;
end

% Apply heat source at center node
center_coord = [0.5, 0.5];
[~, center_node] = min(vecnorm(nodes - center_coord, 2, 2));
F(center_node) = Q;

% Apply Dirichlet BC: bottom edge (y=0)
tol = 1e-6;
fixed_nodes = find(abs(nodes(:,2)) < tol);
T = zeros(n_nodes, 1);
T(fixed_nodes) = T_fixed;
free_nodes = setdiff(1:n_nodes, fixed_nodes);

% Modify system
F_mod = F(free_nodes) - K(free_nodes, fixed_nodes) * T(fixed_nodes);
K_mod = K(free_nodes, free_nodes);

% Solve
T(free_nodes) = K_mod \ F_mod;

%% Display results
disp('Nodal Temperatures:');
for i = 1:n_nodes
    fprintf('Node %d (%0.1f, %0.1f): T = %.2f°C\n', i, nodes(i,1), nodes(i,2), T(i));
end

% Plot: temperature contour
figure;
trisurf(elements, nodes(:,1), nodes(:,2), T, 'FaceColor','interp');
colorbar;
title('Temperature Distribution (~100 Elements)');
xlabel('x (m)'); ylabel('y (m)'); zlabel('Temperature (°C)');
view(2); axis equal; shading interp;

% Plot temperature along centerline (y = 0.5)
x_line = linspace(0, 1, 200);
T_line = griddata(nodes(:,1), nodes(:,2), T, x_line, 0.5 * ones(size(x_line)));

figure;
plot(x_line, T_line, '-');
title('Temperature along centerline y = 0.5 m');
xlabel('x (m)'); ylabel('Temperature (°C)');
grid on;

